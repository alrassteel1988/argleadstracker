---
name: uae-structural-steel-lead-intelligence
description: Research and qualify UAE companies as potential customers for a structural steel trading company. Use when the user provides a UAE company name and wants a verified company profile, recent and ongoing project intelligence, publicly available procurement/commercial decision-makers, likely structural steel requirements, a 1-10 lead score, and recommended sales actions with citations. Also use for requests such as "research this contractor", "qualify this UAE steel lead", "find procurement contacts", or "what steel could this company buy?".
---

# UAE Structural Steel Lead Intelligence

## Purpose

Research UAE companies as potential customers for a structural steel trading company and convert public information into a practical, source-backed sales intelligence brief.

The user will normally provide only a company name. Perform the research without requiring the user to restate this workflow.

Example input:

`Company: ABC Contracting LLC`

## Core operating rules

1. Use current web research whenever web access is available. Do not rely on memory for current company details, project status, decision-makers, contact details, or other facts that may have changed.
2. Identify the correct UAE entity before doing deep research. If several companies have similar names, use UAE location, website, business activity, parent group, and other evidence to resolve the correct entity. If material ambiguity remains, state it prominently rather than merging data from different companies.
3. Prefer authoritative and first-party sources. Follow the source hierarchy in `references/source-quality.md`.
4. For important factual claims, provide citations or source links when the environment supports them.
5. Never invent, extrapolate, or pattern-generate a person's name, title, email address, telephone number, project, client, consultant, award date, completion date, or company fact.
6. Do not generate guessed email formats such as `firstname.lastname@company.com`. Only show an individual email address if it is explicitly published or otherwise verified by a reliable public source.
7. Use only publicly available professional/business information for decision-makers. Do not seek or expose sensitive personal data or private contact details.
8. If a field cannot be verified, write `Not publicly found`.
9. Clearly separate verified facts from reasonable sales inferences. Never present an inference as a fact.
10. Prioritize UAE project information from the most recent 3 years, while allowing older major projects when they help establish the company's capabilities or buying pattern.
11. Treat project status as time-sensitive. Verify whether a project is announced, tendering, awarded, under construction, substantially completed, completed, paused, or cancelled whenever credible information is available.
12. Prefer concise, sales-useful output over long generic corporate history.

## Workflow

### Step 1 — Verify the company identity

Establish that the researched company is the intended UAE entity.

Capture where available:

- Full legal/company name
- Common trading name
- Year established
- Headquarters
- UAE branches/offices
- Official website
- Main telephone number
- General/company email
- Official contact page
- Parent/group company
- Main business activities
- Main products and services
- Industries and sectors served
- Company classification: contractor, EPC contractor, steel fabricator, developer, trader, manufacturer, subcontractor, consultant, or other
- Important clients, if credibly documented

When names conflict across sources, prefer the official company website, UAE government/registry information where accessible, parent group sources, and established business directories over scraped or low-quality listing sites.

### Step 2 — Determine structural-steel relevance

Classify the company's likely relationship to structural steel.

Consider whether the company:

- Directly procures structural steel
- Fabricates structural steel
- Subcontracts steel fabrication/erection
- Executes warehouses, factories, logistics facilities, industrial buildings, infrastructure, bridges, plants, oil & gas works, marine works, utilities, high-rise buildings, data centers, airports, malls, stadiums, or other steel-intensive projects
- Acts as a developer or client that may influence specifications but not purchase directly
- Is itself a steel trader or competitor rather than a customer

Assign one preliminary category:

- `Direct Buyer`
- `Likely Buyer`
- `Indirect Influencer`
- `Low-Relevance Buyer`
- `Potential Competitor`
- `Insufficient Evidence`

Explain the basis briefly.

### Step 3 — Research project activity

Find publicly verifiable:

- Recently awarded projects
- Ongoing projects
- Previous major projects
- Announced upcoming projects

Prioritize UAE projects from the most recent 3 years.

For each project, identify whenever available:

- Project name
- Client/developer
- Main contractor
- Consultant
- Location
- Company's role
- Award date or announcement date
- Current status
- Expected completion
- Structural-steel relevance
- Source

Do not list the same project in multiple sections unless the status changed and the distinction is important. Consolidate duplicate project names and alternative spellings.

For structural-steel relevance, use one of:

- `High` — clearly steel-intensive or directly related to structural steel/fabrication
- `Medium` — likely to contain meaningful structural steel scope
- `Low` — limited steel opportunity
- `Unknown` — insufficient evidence

When estimating steel relevance, label the explanation as an inference unless a source explicitly states the steel scope.

### Step 4 — Find procurement and commercial decision-makers

Search for current, publicly verifiable professional information for roles such as:

- Procurement Manager
- Purchasing Manager
- Purchase Manager
- Procurement Engineer
- Supply Chain Manager
- Commercial Manager
- Contracts Manager
- Estimation Manager
- Project Manager
- Construction Manager
- General Manager
- Managing Director

Prioritize procurement, purchasing, supply chain, commercial, contracts, and project procurement roles over senior executives when the company is large.

For smaller firms, General Manager or Managing Director may be commercially relevant.

For each person provide:

- Full name
- Current job title
- Company
- Location
- Publicly available business email, if verified
- Publicly available business telephone, if verified
- Public professional profile or source
- Confidence level

Confidence levels:

- `High` — current role confirmed by an official company source or at least two credible recent sources
- `Medium` — one credible recent professional/business source supports the role
- `Low` — older or incomplete evidence; include only if potentially useful and clearly label it

Do not present former employees as current contacts. Check recency whenever possible.

If an individual business email or phone is not publicly verified, write `Not publicly found` and, when available, provide the company's official procurement/general contact channel instead.

### Step 5 — Evaluate likely structural-steel requirements

Assess whether the company is likely to purchase or influence procurement of:

- Universal Beams (UB)
- Universal Columns (UC)
- I-Beams
- H-Beams
- Channels
- Angles
- Plates
- Flat bars
- Hollow sections: RHS, SHS, CHS
- Pipes
- Sheet piles
- Other relevant structural steel products

For each likely material, connect the inference to company activity or project type. Do not claim that the company definitely buys a product unless a source confirms it.

Use these demand labels:

- `HIGH` — strong evidence of recurring or substantial steel-intensive activity
- `MEDIUM` — meaningful but project-dependent demand
- `LOW` — limited fit or indirect buying role
- `UNKNOWN` — insufficient evidence

Also identify likely buying triggers where supported or reasonably inferred, such as:

- New project award
- Mobilization/start of construction
- Fabrication package
- Warehouse/industrial build
- Infrastructure package
- Urgent stock requirement
- Replacement/additional quantities
- Mill-direct requirement
- Short lead-time requirement

### Step 6 — Score the lead from 1 to 10

Use the scoring model in `references/lead-scoring.md`.

Score the company on:

- Current project activity
- Structural-steel relevance
- Project scale/volume potential
- Procurement accessibility
- UAE activity/presence
- Likelihood of recurring purchases

Calculate a weighted score and convert it to a 1-10 lead score. Show the component scores so the rating is auditable.

Do not inflate the score because information is missing. Missing evidence should lower confidence and, where relevant, the component score.

### Step 7 — Recommend a practical sales action

Recommend:

- Best person or department to approach first
- Most relevant sales angle
- One active/recent project to reference, if verified
- Products most likely to be relevant
- Suggested next action

Sales recommendations should be specific to the evidence found. Avoid generic advice such as "send a company profile" unless it is paired with a concrete reason or target.

Examples of useful sales angles include:

- Immediate UAE stock availability
- Fast delivery to project site
- Project-specific structural section pricing
- Mill-direct pricing for bulk quantities
- Cut-length or special-size availability
- Alternative origin/options subject to specification approval
- Regular call-off supply
- Credit/commercial terms, only when appropriate and not assumed

### Step 8 — Final quality check

Before responding, verify that:

- The correct company entity was researched.
- Current information was checked with web research when available.
- Important claims have supporting sources/citations.
- No email, phone, person, project, or date was guessed.
- Current and former employees are not mixed.
- Duplicate projects are consolidated.
- Project status is not stated more confidently than the evidence supports.
- Verified facts and inferences are visibly distinguished.
- The lead score is consistent with the evidence.
- The sales recommendation follows from the research.

## Required output format

# UAE STRUCTURAL STEEL LEAD INTELLIGENCE

**Research date:** [date]

## Executive Lead Snapshot

- **Company:**
- **Company Type:**
- **Buyer Classification:** Direct Buyer / Likely Buyer / Indirect Influencer / Low-Relevance Buyer / Potential Competitor / Insufficient Evidence
- **Lead Score:** X/10
- **Steel Demand:** HIGH / MEDIUM / LOW / UNKNOWN
- **Procurement Accessibility:** High / Medium / Low / Unknown
- **Best Sales Entry Point:**
- **Top Opportunity:**

## COMPANY PROFILE

- **Company:**
- **Established:**
- **Headquarters:**
- **Website:**
- **Telephone:**
- **Email:**
- **Contact Page:**
- **Locations:**
- **Parent/Group:**
- **Company Type:**
- **Main Activities:**
- **Main Products/Services:**
- **Industries Served:**
- **Important Clients:**

## PROJECT INTELLIGENCE

### Recently Awarded Projects

For each relevant project:

**Project:**  
**Client/Developer:**  
**Main Contractor:**  
**Consultant:**  
**Location:**  
**Company Role:**  
**Award/Announcement Date:**  
**Current Status:**  
**Expected Completion:**  
**Structural-Steel Relevance:** High / Medium / Low / Unknown  
**Evidence/Reason:**  
**Source:**

If none can be verified, state: `No recently awarded UAE projects publicly verified.`

### Ongoing Projects

Use the same project fields.

If none can be verified, state: `No ongoing UAE projects publicly verified.`

### Previous Relevant Projects

List only projects that help establish capability, buying pattern, or structural-steel relevance. Use the same project fields where information is available.

## PROCUREMENT CONTACTS

Rank contacts by sales relevance.

### Contact 1

- **Name:**
- **Position:**
- **Company:**
- **Location:**
- **Business Email:**
- **Business Telephone:**
- **Public Professional Source:**
- **Confidence:** High / Medium / Low
- **Why Relevant:**

Repeat for additional useful contacts.

If no named procurement contact is verified, include:

- **Named procurement contact:** Not publicly found
- **Best verified company contact channel:** [official general/procurement channel, if available]

## STRUCTURAL STEEL OPPORTUNITY

**Steel Demand:** HIGH / MEDIUM / LOW / UNKNOWN

### Likely Required Materials

Use a table where practical:

| Material | Likelihood | Reason / Project Link | Fact or Inference |
|---|---|---|---|
| UB / UC | High/Medium/Low/Unknown | ... | Verified / Inference |

Consider all relevant materials, but do not pad the table with products that have no plausible link to the company's activity.

### Buying Pattern / Opportunity

Explain briefly whether demand is likely to be recurring, project-based, fabrication-driven, indirect, or uncertain.

## LEAD SCORE

Show the component assessment:

| Factor | Weight | Score | Evidence |
|---|---:|---:|---|
| Current project activity | 25% | /10 | |
| Structural-steel relevance | 25% | /10 | |
| Project scale / volume potential | 15% | /10 | |
| Procurement accessibility | 15% | /10 | |
| UAE activity / presence | 10% | /10 | |
| Recurring purchase likelihood | 10% | /10 | |

**Weighted Lead Score:** X.X/10  
**Displayed Lead Score:** X/10  
**Lead Priority:** A / B / C / D

Priority mapping:

- A = 8.0–10.0
- B = 6.0–7.9
- C = 4.0–5.9
- D = below 4.0

## SALES RECOMMENDATION

- **Best person/department to approach:**
- **Recommended sales angle:**
- **Known active/recent project to reference:**
- **Most relevant products:**
- **Suggested next action:**
- **Suggested opening message angle:** One sentence only; do not fabricate familiarity or claim prior knowledge beyond the verified research.

## RESEARCH QUALITY

### Verified Information

Summarize the strongest verified findings.

### Reasonable Inferences

List conclusions inferred from project/company activity and clearly label them as inference.

### Not Publicly Found / Unverified

List important gaps, such as procurement emails, project completion dates, consultant details, or named contacts.

### Confidence Summary

- **Company identity:** High / Medium / Low
- **Company profile:** High / Medium / Low
- **Project intelligence:** High / Medium / Low
- **Procurement contacts:** High / Medium / Low
- **Steel opportunity assessment:** High / Medium / Low

## SOURCES

Provide the most useful sources in order of authority and relevance. Prefer official company, developer/client, government, tender/authority, and reputable project/industry sources.

## Behavior for follow-up requests

If the user subsequently asks for any of the following, reuse the research already completed and update only what is necessary:

- Draft a sales email or WhatsApp message to the prospect
- Find additional procurement contacts
- Compare this lead with another company
- Build a call plan
- Find more projects
- Re-score the lead after new information
- Export multiple researched leads into a table or spreadsheet

When asked to compare multiple companies, keep the same scoring model across all companies.
