# UAE Structural Steel Lead Intelligence Skill

This package contains a reusable ChatGPT/OpenAI Skill for researching and qualifying UAE companies as potential structural steel customers.

## Typical use

After installing the skill, enter a company name, for example:

`Research Al Naboodah Construction using the UAE Structural Steel Lead Intelligence skill.`

Or explicitly invoke the installed skill by its skill name where supported:

`Use the uae-structural-steel-lead-intelligence skill to research [Company Name].`

## Contents

- `SKILL.md` — main workflow and output requirements
- `references/source-quality.md` — source hierarchy and verification rules
- `references/lead-scoring.md` — standardized 1–10 lead scoring model

## Important

For best results, use the skill in an environment with web research/search enabled. The skill is designed not to fabricate contact details or project information and to distinguish verified facts from sales inferences.
