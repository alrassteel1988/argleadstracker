# Lead Scoring Model

Score each factor from 0 to 10, then apply the weight.

## 1. Current project activity — 25%

- 0–2: No recent UAE project evidence or business appears inactive
- 3–4: Limited recent activity; mostly older references
- 5–6: At least one credible active/recent project
- 7–8: Several active/recent UAE projects or a meaningful recent award
- 9–10: Strong pipeline of major active/awarded UAE projects

## 2. Structural-steel relevance — 25%

- 0–2: Minimal structural steel relevance
- 3–4: Indirect or occasional relevance
- 5–6: Meaningful steel use likely in some projects
- 7–8: Steel-intensive contractor/fabricator/project portfolio
- 9–10: Structural steel is central to the company's work or procurement

## 3. Project scale / volume potential — 15%

- 0–2: Very small-scale work
- 3–4: Small to medium projects
- 5–6: Medium projects with plausible recurring tonnage
- 7–8: Large industrial/commercial/infrastructure projects
- 9–10: Major multi-project or mega-project exposure with high potential tonnage

Do not invent tonnage. Score from visible project type/scale evidence.

## 4. Procurement accessibility — 15%

- 0–2: No verified business contact route
- 3–4: Only generic contact channel
- 5–6: Relevant department or one current commercial/project contact identified
- 7–8: Current procurement/purchasing decision-maker identified with a viable business contact route
- 9–10: Multiple verified procurement contacts and clear company procurement channels

A guessed email never increases this score.

## 5. UAE activity / presence — 10%

- 0–2: Little or no confirmed UAE activity
- 3–4: Limited UAE presence
- 5–6: Established UAE office and operating activity
- 7–8: Multiple UAE projects/offices or strong emirate coverage
- 9–10: Major, sustained UAE footprint across several projects/emirates

## 6. Recurring purchase likelihood — 10%

- 0–2: One-off or unlikely buyer
- 3–4: Occasional project-dependent need
- 5–6: Periodic steel demand likely
- 7–8: Regular project/fabrication pipeline suggests recurring purchases
- 9–10: Business model strongly implies continuous or high-frequency structural steel procurement

## Formula

Weighted score =

`(Project Activity × 0.25) + (Steel Relevance × 0.25) + (Scale × 0.15) + (Procurement Accessibility × 0.15) + (UAE Presence × 0.10) + (Recurring Purchase Likelihood × 0.10)`

Round the weighted score to one decimal place.

Displayed lead score = nearest whole number from 1 to 10, while still showing the weighted decimal score.

## Priority mapping

- A: 8.0–10.0 — high-priority prospect
- B: 6.0–7.9 — worthwhile active prospect
- C: 4.0–5.9 — nurture or research further
- D: below 4.0 — low priority unless strategic context changes

## Confidence adjustment

Do not mechanically reduce the weighted score for missing data, but avoid assigning high component scores without supporting evidence. If overall evidence is sparse, explicitly mark research confidence as Low.
