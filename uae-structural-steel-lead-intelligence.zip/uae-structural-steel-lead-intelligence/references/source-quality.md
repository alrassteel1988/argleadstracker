# Source Quality and Verification Rules

Use this hierarchy when researching UAE company and project intelligence.

## Tier 1 — Highest confidence

Prefer these whenever available:

- Official company website
- Official parent/group website
- Official developer/client website
- UAE federal or emirate government websites
- Free-zone, municipality, economic department, authority, or regulator websites
- Official tender/procurement portals
- Official press releases
- Official project pages

## Tier 2 — Strong secondary sources

- Established construction/project intelligence publications
- Reputable UAE or international business media
- Recognized engineering/construction trade publications
- Public professional profiles that clearly identify current employment
- Major consultant, contractor, developer, or supplier announcements

## Tier 3 — Supporting sources

Use cautiously and corroborate important claims where possible:

- Business directories
- Industry directories
- Conference/speaker biographies
- Job advertisements
- Supplier/customer case studies
- Search-result snippets

## Low-confidence sources

Do not rely on these alone for important claims:

- Scraped people-search pages
- Unattributed company databases
- SEO lead-generation pages
- Outdated cached profiles
- Forums or anonymous posts
- AI-generated summaries without primary citations

## Verification rules

- Prefer recent sources for current employees and active projects.
- An official source can support a claim by itself when it is clearly current.
- For a named employee found only on a secondary source, seek a second corroborating source when practical.
- Never infer an individual email from a company email pattern.
- Never assume that an old project remains ongoing.
- Never assume a project award means the researched company received the structural steel package.
- Treat steel-product requirements as inference unless explicitly documented.
- When sources disagree, state the conflict and prefer the most authoritative and recent evidence.
